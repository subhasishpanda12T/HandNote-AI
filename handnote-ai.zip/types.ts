
export enum FontStyle {
  REGULAR = 'SP-Regular',
  NEAT = 'SP-Neat',
  CURSIVE = 'SP-Cursive',
  ROUNDED = 'SP-Rounded',
  EXAM = 'SP-Exam Style',
  SIGNATURE = 'SP-Signature Style',
  CUSTOM = 'Custom Handwriting',
}

export enum PenColor {
  BLACK = 'black',
  BLUE = 'blue',
  RED = 'red',
  GREEN = 'green',
}

export enum HighlighterColor {
  NONE = 'none',
  YELLOW = 'yellow',
  BLUE = 'blue',
}

export enum NoteBlockType {
  HEADING = 'HEADING',
  SUBHEADING = 'SUBHEADING',
  PARAGRAPH = 'PARAGRAPH',
  BULLET = 'BULLET',
  TABLE = 'TABLE',
  FLOWCHART = 'FLOWCHART',
  DEFINITION = 'DEFINITION',
  FLASHCARD = 'FLASHCARD',
  MIND_MAP = 'MIND_MAP',
  DRAWING = 'DRAWING',
  IMAGE = 'IMAGE',
  TEXTBOX = 'TEXTBOX',
  RICH_TEXT = 'RICH_TEXT',
}

export enum NotebookTheme {
  RULED = 'Ruled',
  GRID = 'Grid',
  DOTTED = 'Dotted',
  BLANK = 'Blank',
  EXAM = 'Exam Sheet',
  DARK = 'Blackboard',
}

export interface TableData {
  headers: string[];
  rows: string[][];
}

export interface FlashcardData {
  term: string;
  definition: string;
}

export interface MindMapData {
  center: string;
  branches: {
    label: string;
    items: string[];
  }[];
}

export interface NoteBlock {
  id: string;
  type: NoteBlockType;
  content: string | TableData | FlashcardData | MindMapData;
  font: FontStyle;
  color: PenColor;
  highlight: HighlighterColor;
  timestamp: number;
}

export interface NotebookState {
  subject: string;
  chapter: string;
  blocks: NoteBlock[];
}

export interface ToolResponse {
  functionResponses: {
    name: string;
    id: string;
    response: object;
  }[];
}
