
import { useEffect, useRef, useState, useCallback } from 'react';
import { GoogleGenAI, LiveServerMessage, Modality, Type, FunctionDeclaration } from '@google/genai';
import { createBlob, decodeAudioData, SAMPLE_RATE } from '../utils/audioUtils';
import { SYSTEM_INSTRUCTION } from '../constants';
import { NoteBlockType, FontStyle, PenColor, HighlighterColor } from '../types';

// --- Function Declarations for Gemini Tools ---

const addNoteBlockDecl: FunctionDeclaration = {
  name: 'addNoteBlock',
  description: 'Add a structured note block to the notebook. Use this for headings, paragraphs, tables, and visual elements.',
  parameters: {
    type: Type.OBJECT,
    properties: {
      type: { 
        type: Type.STRING, 
        enum: Object.values(NoteBlockType),
        description: 'The type of visual block to create.' 
      },
      content: { 
        type: Type.STRING, 
        description: 'The content. For TABLES: JSON {headers:[], rows:[][]}. For FLASHCARDS: JSON {term:"", definition:""}. For MIND_MAP: JSON. For DRAWING: SVG string. For TEXTBOX: text string. For RICH_TEXT: HTML string.'
      },
    },
    required: ['type', 'content'],
  },
};

const updateStyleDecl: FunctionDeclaration = {
  name: 'updateStyle',
  description: 'Update the current pen style or font.',
  parameters: {
    type: Type.OBJECT,
    properties: {
      font: { type: Type.STRING, enum: Object.values(FontStyle) },
      color: { type: Type.STRING, enum: Object.values(PenColor) },
      highlight: { type: Type.STRING, enum: Object.values(HighlighterColor) },
    },
  },
};

const setMetadataDecl: FunctionDeclaration = {
  name: 'setMetadata',
  description: 'Set the subject and chapter of the current class.',
  parameters: {
    type: Type.OBJECT,
    properties: {
      subject: { type: Type.STRING },
      chapter: { type: Type.STRING },
    },
    required: ['subject'],
  },
};

interface UseLiveAPIProps {
  onAddBlock: (type: NoteBlockType, content: any) => void;
  onUpdateStyle: (style: { font?: FontStyle; color?: PenColor; highlight?: HighlighterColor }) => void;
  onSetMetadata: (subject: string, chapter: string) => void;
}

export const useLiveAPI = ({ onAddBlock, onUpdateStyle, onSetMetadata }: UseLiveAPIProps) => {
  const [isConnected, setIsConnected] = useState(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [volume, setVolume] = useState(1);
  const [isMicOn, setIsMicOn] = useState(true);
  const [analyserNode, setAnalyserNode] = useState<AnalyserNode | null>(null);
  
  // Refs to manage resources without triggering re-renders
  const sessionRef = useRef<any>(null);
  const sessionPromiseRef = useRef<Promise<any> | null>(null);
  const audioContextRef = useRef<AudioContext | null>(null);
  const gainNodeRef = useRef<GainNode | null>(null);
  const analyserRef = useRef<AnalyserNode | null>(null); 
  const streamRef = useRef<MediaStream | null>(null);
  const processorRef = useRef<ScriptProcessorNode | null>(null);
  const nextStartTimeRef = useRef<number>(0);
  const audioSourcesRef = useRef<Set<AudioBufferSourceNode>>(new Set());
  const isMicOnRef = useRef(true);

  // Video Refs
  const videoStreamRef = useRef<MediaStream | null>(null);
  const videoIntervalRef = useRef<number | null>(null);

  // Sync Ref with State
  useEffect(() => {
    isMicOnRef.current = isMicOn;
  }, [isMicOn]);

  const stopVideo = useCallback(() => {
    if (videoIntervalRef.current) {
      window.clearInterval(videoIntervalRef.current);
      videoIntervalRef.current = null;
    }
    if (videoStreamRef.current) {
      videoStreamRef.current.getTracks().forEach(track => track.stop());
      videoStreamRef.current = null;
    }
  }, []);

  const startVideo = useCallback(async (videoElement: HTMLVideoElement) => {
    if (!isConnected) {
        console.warn("Cannot start video: Session not connected");
        return;
    }
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ video: true });
      videoStreamRef.current = stream;
      videoElement.srcObject = stream;
      await videoElement.play();

      const canvas = document.createElement('canvas');
      const ctx = canvas.getContext('2d');
      
      videoIntervalRef.current = window.setInterval(() => {
          if (videoElement.readyState >= 2 && ctx) {
              canvas.width = 640; 
              const scale = 640 / videoElement.videoWidth;
              canvas.height = videoElement.videoHeight * scale;
              
              ctx.drawImage(videoElement, 0, 0, canvas.width, canvas.height);
              const base64 = canvas.toDataURL('image/jpeg', 0.6).split(',')[1];
              
              if (sessionRef.current && sessionRef.current.sendRealtimeInput) {
                  sessionRef.current.sendRealtimeInput({ 
                      media: {
                          mimeType: 'image/jpeg', 
                          data: base64 
                      }
                  });
              }
          }
      }, 500);

    } catch (e) {
      console.error("Failed to start video", e);
    }
  }, [isConnected]);

  const sendImage = useCallback((base64Data: string, mimeType: string = 'image/png') => {
    if (!isConnected || !sessionRef.current) return;
    if (sessionRef.current.sendRealtimeInput) {
        sessionRef.current.sendRealtimeInput({
          media: {
              mimeType, 
              data: base64Data 
          }
        });
    }
  }, [isConnected]);

  const sendText = useCallback((text: string) => {
    if (!isConnected || !sessionRef.current) {
        console.warn("Attempted to send text while not connected.");
        return;
    }
    
    try {
       // Support different SDK method signatures just in case
       if (typeof sessionRef.current.send === 'function') {
          sessionRef.current.send([{ text }]);
       } else if (typeof sessionRef.current.sendClientContent === 'function') {
          sessionRef.current.sendClientContent([{ text }]);
       } else {
           console.error("No valid send method found on session object", sessionRef.current);
       }
    } catch(e) {
       console.error("Failed to send text:", e);
    }
  }, [isConnected]);

  const disconnect = useCallback(async () => {
    stopVideo(); 

    if (sessionPromiseRef.current) {
      try {
        await sessionPromiseRef.current;
      } catch (e) {
        console.warn("Error handling disconnect:", e);
      }
      sessionRef.current = null;
      sessionPromiseRef.current = null;
    }
    if (processorRef.current) {
      processorRef.current.disconnect();
      processorRef.current = null;
    }
    if (streamRef.current) {
      streamRef.current.getTracks().forEach(track => track.stop());
      streamRef.current = null;
    }
    if (audioContextRef.current) {
      audioContextRef.current.close();
      audioContextRef.current = null;
      gainNodeRef.current = null;
      analyserRef.current = null;
      setAnalyserNode(null);
    }
    audioSourcesRef.current.forEach(source => source.stop());
    audioSourcesRef.current.clear();
    
    setIsConnected(false);
  }, [stopVideo]);

  const connect = useCallback(async () => {
    try {
      setErrorMessage(null);
      // Hardcoded API key as provided
      const apiKey = "AIzaSyADaVvchJqREXIc_P0DkBVD-o4I6bnJysw";

      if (!apiKey) {
        setErrorMessage("API Key Missing");
        return;
      }

      const ai = new GoogleGenAI({ apiKey });

      const audioCtx = new (window.AudioContext || (window as any).webkitAudioContext)({
        sampleRate: SAMPLE_RATE,
      });
      audioContextRef.current = audioCtx;

      if (audioCtx.state === 'suspended') {
         await audioCtx.resume();
      }

      const analyser = audioCtx.createAnalyser();
      analyser.fftSize = 256;
      analyserRef.current = analyser;
      setAnalyserNode(analyser); 

      const gainNode = audioCtx.createGain();
      gainNode.gain.value = volume;
      gainNode.connect(audioCtx.destination);
      gainNodeRef.current = gainNode;

      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      streamRef.current = stream;
      const source = audioCtx.createMediaStreamSource(stream);
      
      source.connect(analyser);

      const processor = audioCtx.createScriptProcessor(4096, 1, 1);
      processorRef.current = processor;
      
      processor.onaudioprocess = (e) => {
        // IMPORTANT: Check isMicOnRef to determine if we should send audio
        if (!isMicOnRef.current || !sessionRef.current) return;

        const inputData = e.inputBuffer.getChannelData(0);
        const blob = createBlob(inputData);
        
        // Send audio data if method exists
        if (sessionRef.current && sessionRef.current.sendRealtimeInput) {
            sessionRef.current.sendRealtimeInput({ 
                media: {
                    mimeType: blob.mimeType, 
                    data: blob.data 
                }
            });
        }
      };

      source.connect(processor);
      processor.connect(audioCtx.destination); 

      // Init Session
      sessionPromiseRef.current = ai.live.connect({
        model: 'gemini-2.5-flash-native-audio-preview-09-2025',
        config: {
          responseModalities: [Modality.AUDIO], 
          systemInstruction: { parts: [{ text: SYSTEM_INSTRUCTION }] },
          tools: [
            { functionDeclarations: [addNoteBlockDecl, updateStyleDecl, setMetadataDecl] },
            { googleSearch: {} }
          ],
        },
        callbacks: {
          onopen: () => {
            console.log("Session opened");
          },
          onmessage: async (message: LiveServerMessage) => {
            if (message.toolCall) {
              const responses = [];
              for (const fc of message.toolCall.functionCalls) {
                let result: { ok: boolean; error?: string } = { ok: true };
                try {
                  console.log(`Executing tool: ${fc.name}`, fc.args);
                  if (fc.name === 'addNoteBlock') {
                    const args = fc.args as any;
                    onAddBlock(args.type, args.content);
                  } else if (fc.name === 'updateStyle') {
                    onUpdateStyle(fc.args as any);
                  } else if (fc.name === 'setMetadata') {
                    const args = fc.args as any;
                    onSetMetadata(args.subject, args.chapter || '');
                  }
                } catch (e) {
                  console.error("Error executing tool", e);
                  result = { ok: false, error: (e as Error).message };
                }
                responses.push({ id: fc.id, name: fc.name, response: result });
              }
              if (sessionPromiseRef.current) {
                sessionPromiseRef.current.then(session => {
                  if (session.sendToolResponse) {
                      session.sendToolResponse({ functionResponses: responses });
                  }
                });
              }
            }

            const base64Audio = message.serverContent?.modelTurn?.parts?.[0]?.inlineData?.data;
            if (base64Audio && audioContextRef.current && gainNodeRef.current) {
              const audioCtx = audioContextRef.current;
              const buffer = await decodeAudioData(base64Audio, audioCtx);
              
              const source = audioCtx.createBufferSource();
              source.buffer = buffer;
              source.connect(gainNodeRef.current);
              
              if (analyserRef.current) {
                 source.connect(analyserRef.current);
              }

              const currentTime = audioCtx.currentTime;
              const startTime = Math.max(currentTime, nextStartTimeRef.current);
              source.start(startTime);
              nextStartTimeRef.current = startTime + buffer.duration;

              audioSourcesRef.current.add(source);
              source.onended = () => {
                  audioSourcesRef.current.delete(source);
              };
            }
            
            if (message.serverContent?.interrupted) {
                audioSourcesRef.current.forEach(source => source.stop());
                audioSourcesRef.current.clear();
                nextStartTimeRef.current = 0;
            }
          },
          onclose: () => {
            console.log("Session closed");
            setIsConnected(false);
          },
          onerror: (err) => {
            console.error("Session error", err);
            setErrorMessage("Session Error: " + (err.message || "Unknown"));
            setIsConnected(false);
            disconnect();
          }
        }
      });
      
      const session = await sessionPromiseRef.current;
      sessionRef.current = session;
      
      setIsConnected(true);
      nextStartTimeRef.current = 0;

    } catch (e) {
      console.error("Connection failed", e);
      setErrorMessage("Connection Failed: " + (e as Error).message);
      setIsConnected(false);
    }
  }, [onAddBlock, onUpdateStyle, onSetMetadata, disconnect, volume]);

  const updateVolume = useCallback((newVolume: number) => {
    setVolume(newVolume);
    if (gainNodeRef.current) {
      gainNodeRef.current.gain.value = newVolume;
    }
  }, []);

  const toggleMic = useCallback(() => {
    setIsMicOn(prev => !prev);
  }, []);

  return {
    connect,
    disconnect,
    startVideo,
    stopVideo,
    sendImage,
    sendText,
    isConnected,
    errorMessage,
    volume,
    setVolume: updateVolume,
    isMicOn,
    toggleMic,
    analyserNode
  };
};
