import React, { useState, useRef, useEffect, useLayoutEffect } from 'react';
import { useLiveAPI } from './hooks/useLiveAPI';
import { NoteBlock, NoteBlockType, FontStyle, PenColor, HighlighterColor, NotebookState, TableData, FlashcardData, MindMapData, NotebookTheme } from './types';
import { FONT_FAMILY_MAP, PEN_COLOR_MAP, HIGHLIGHTER_COLOR_MAP } from './constants';
import { Mic, MicOff, StopCircle, Eraser, PenTool, BookOpen, Camera, CameraOff, Highlighter, X, Pencil, BrainCircuit, MessageSquare, Send, HelpCircle, ChevronDown, Image as ImageIcon, FileDown, Network, Loader2, Volume2, VolumeX, Pause, Play, StickyNote, FileText, Youtube, Upload, Palette, Power } from 'lucide-react';

// Declare Globals for CDNs to prevent build errors
declare global {
  interface Window {
    fabric: any;
    html2pdf: any;
    html2canvas: any;
    Quill: any;
  }
}

// Helper to safely parse JSON content from AI which might include markdown code blocks
const safeParse = (content: string | object): any => {
  if (typeof content === 'object') return content;
  if (typeof content !== 'string') return null;
  
  try {
    // Remove markdown code blocks if present
    let cleaned = content.replace(/```json/g, '').replace(/```/g, '').trim();
    return JSON.parse(cleaned);
  } catch (e) {
    console.error("JSON Parse error", e, content);
    return null;
  }
};

// Reusable Editable Text Component
const Editable = ({ 
    tagName: Tag = 'div', 
    content, 
    onSave, 
    className, 
    style,
    disabled
}: {
    tagName?: any;
    content: string;
    onSave: (val: string) => void;
    className?: string;
    style?: React.CSSProperties;
    disabled?: boolean;
}) => {
    const handleBlur = (e: React.FocusEvent<HTMLElement>) => {
        const newText = e.currentTarget.innerText;
        if (newText !== content) {
            onSave(newText);
        }
    };

    return (
        <Tag
            className={`${className || ''} ${!disabled ? 'hover:bg-black/5 focus:bg-yellow-100/50 focus:outline-none focus:ring-1 focus:ring-blue-300/50 rounded transition-colors cursor-text' : ''}`}
            style={style}
            contentEditable={!disabled}
            suppressContentEditableWarning
            onBlur={handleBlur}
            dangerouslySetInnerHTML={{ __html: content }}
        />
    );
};

const RichTextEditor = ({ 
    id, 
    initialContent, 
    onUpdate 
}: { 
    id: string, 
    initialContent: string, 
    onUpdate: (content: string) => void 
}) => {
    const editorRef = useRef<HTMLDivElement>(null);
    const quillInstance = useRef<any>(null);
    const toolbarId = `toolbar-${id}`;
    const editorId = `editor-${id}`;

    useLayoutEffect(() => {
        if (!window.Quill) {
            console.warn("Quill not loaded");
            return;
        }

        const quill = new window.Quill(`#${editorId}`, {
            theme: 'snow',
            modules: {
                toolbar: {
                    container: `#${toolbarId}`,
                },
                formula: true
            }
        });

        if (initialContent) {
            quill.clipboard.dangerouslyPasteHTML(initialContent);
        }

        quill.on('text-change', () => {
            onUpdate(quill.root.innerHTML);
        });

        quillInstance.current = quill;

        const attachMathHandler = (btnId: string, formula: string) => {
            const btn = document.getElementById(btnId);
            if (btn) {
                btn.onclick = () => {
                    const range = quill.getSelection(true);
                    quill.insertEmbed(range.index, 'formula', formula);
                    quill.setSelection(range.index + 1);
                };
            }
        };

        attachMathHandler(`math-inline-${id}`, 'a^2 + b^2 = c^2');
        attachMathHandler(`math-block-${id}`, '\\frac{a}{b}');
        attachMathHandler(`add-op-${id}`, '+');
        attachMathHandler(`sub-op-${id}`, '-');
        attachMathHandler(`mul-op-${id}`, '\\times');
        attachMathHandler(`div-op-${id}`, '\\div');

    }, []);

    return (
        <div className="my-6 bg-white rounded-lg shadow-md border border-slate-200 overflow-hidden">
            <div id={toolbarId} className="bg-slate-50 border-b border-slate-200 p-1">
                <span className="ql-formats">
                   <select className="ql-header">
                        <option value="0">Normal</option>
                        <option value="1">H1</option>
                        <option value="2">H2</option>
                        <option value="3">H3</option>
                   </select>
                </span>
                <span className="ql-formats">
                   <button className="ql-bold"></button>
                   <button className="ql-italic"></button>
                   <button className="ql-underline"></button>
                   <button className="ql-strike"></button>
                </span>
                <span className="ql-formats">
                   <select className="ql-color"></select>
                   <select className="ql-background"></select>
                </span>
                <span className="ql-formats">
                   <button className="ql-script" value="sub"></button>
                   <button className="ql-script" value="super"></button>
                </span>
                <span className="ql-formats">
                   <button className="ql-list" value="ordered"></button>
                   <button className="ql-list" value="bullet"></button>
                </span>
                <span className="ql-formats">
                    <button className="ql-blockquote"></button>
                    <button className="ql-code-block"></button>
                </span>
                <span className="ql-formats">
                   <button className="ql-clean"></button>
                </span>
                <span className="ql-formats border-l pl-2 ml-2 border-slate-300">
                   <button id={`math-inline-${id}`} className="px-2 font-serif italic font-bold text-xs w-auto">f(x)</button>
                   <button id={`math-block-${id}`} className="px-2 font-serif font-bold text-xs w-auto">∫</button>
                   <button id={`add-op-${id}`} className="px-1 w-auto font-bold">+</button>
                   <button id={`sub-op-${id}`} className="px-1 w-auto font-bold">-</button>
                   <button id={`mul-op-${id}`} className="px-1 w-auto font-bold">×</button>
                   <button id={`div-op-${id}`} className="px-1 w-auto font-bold">÷</button>
                </span>
            </div>
            <div id={editorId} style={{ minHeight: '150px' }}></div>
        </div>
    );
};

const DigitalRecorder = ({ 
    isConnected, 
    isMicOn,
    volume, 
    onToggleMic,
    onVolumeChange, 
    analyser 
}: { 
    isConnected: boolean, 
    isMicOn: boolean,
    volume: number, 
    onToggleMic: () => void,
    onVolumeChange: (v: number) => void, 
    analyser: AnalyserNode | null 
}) => {
    const canvasRef = useRef<HTMLCanvasElement>(null);
    
    useEffect(() => {
        if (!analyser || !canvasRef.current || !isConnected) return;
        
        const canvas = canvasRef.current;
        const ctx = canvas.getContext('2d');
        if (!ctx) return;
        
        const bufferLength = analyser.frequencyBinCount;
        const dataArray = new Uint8Array(bufferLength);
        let animationId: number;
        
        const draw = () => {
            animationId = requestAnimationFrame(draw);
            analyser.getByteFrequencyData(dataArray);
            
            ctx.clearRect(0, 0, canvas.width, canvas.height);
            const bars = 12;
            const gap = 2;
            const barWidth = (canvas.width - (bars - 1) * gap) / bars;
            const step = Math.floor(bufferLength / bars);
            
            for (let i = 0; i < bars; i++) {
                const value = dataArray[i * step];
                const heightPercent = value / 255;
                const filledHeight = Math.max(2, heightPercent * canvas.height);
                let color = '#22c55e';
                if (heightPercent > 0.6) color = '#eab308';
                if (heightPercent > 0.8) color = '#ef4444';
                
                ctx.fillStyle = color;
                ctx.fillRect(i * (barWidth + gap), canvas.height - filledHeight, barWidth, filledHeight);
                
                ctx.fillStyle = '#1e293b';
                ctx.fillRect(i * (barWidth + gap), 0, barWidth, canvas.height - filledHeight - 1);
            }
        };
        
        draw();
        return () => cancelAnimationFrame(animationId);
    }, [analyser, isConnected]);

    return (
        <div className="flex items-center gap-3 bg-slate-900 p-1.5 rounded-lg border border-slate-700 shadow-inner">
            <div className="w-24 h-8 bg-black rounded border border-slate-800 relative overflow-hidden flex items-center justify-center">
                <canvas ref={canvasRef} width={96} height={32} />
                {!isConnected && <span className="text-[9px] text-slate-500 font-mono">OFFLINE</span>}
            </div>
            <div className="flex items-center gap-1">
                <button 
                    onClick={onToggleMic} 
                    disabled={!isConnected}
                    className={`p-1.5 rounded disabled:opacity-30 transition-colors ${!isMicOn ? 'text-red-500 bg-slate-800' : 'text-green-500 hover:bg-slate-800'}`}
                    title={isMicOn ? "Mute Mic" : "Unmute Mic"}
                >
                    {isMicOn ? <Mic size={14} fill="currentColor" /> : <MicOff size={14} />}
                </button>
                <div className="relative group">
                    <button 
                        onClick={() => onVolumeChange(volume === 0 ? 1 : 0)}
                        disabled={!isConnected}
                        className={`p-1.5 rounded disabled:opacity-30 ${volume === 0 ? 'text-red-500' : 'text-slate-400 hover:text-white hover:bg-slate-800'}`}
                    >
                         {volume === 0 ? <VolumeX size={14} /> : <Volume2 size={14} />}
                    </button>
                    <div className="absolute bottom-full left-1/2 -translate-x-1/2 mb-2 hidden group-hover:block">
                        <div className="bg-slate-800 p-2 rounded shadow-xl border border-slate-700 h-24 flex items-center justify-center">
                             <input 
                               type="range" 
                               min="0" 
                               max="1" 
                               step="0.1" 
                               value={volume}
                               onChange={(e) => onVolumeChange(parseFloat(e.target.value))}
                               className="h-20 -rotate-90 w-1.5 bg-slate-600 rounded-lg appearance-none cursor-pointer accent-blue-500"
                             />
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
};

// ... (HandwrittenMindMap and DrawingCanvas components remain unchanged) ...
const HandwrittenMindMap = ({ data, fontStyle, color }: { data: MindMapData, fontStyle: string, color: string }) => {
  return (
    <div className="my-8 py-6 relative flex flex-col items-center w-full select-none" style={{ fontFamily: fontStyle, color: color }}>
       <div 
         className="z-10 border-[3px] px-8 py-4 bg-white/80 shadow-[2px_2px_0px_rgba(0,0,0,0.1)] mb-12 text-2xl font-bold text-center max-w-[80%] transform -rotate-1 transition-transform hover:scale-105 duration-300"
         style={{ borderColor: color, borderRadius: '50% 40% 60% 50% / 60% 50% 60% 40%' }}
       >
          {data.center}
       </div>
       <div className="flex flex-wrap justify-center gap-x-12 gap-y-8 w-full relative z-10 px-4">
          {data.branches.map((branch, idx) => (
            <div key={idx} className="flex flex-col items-center min-w-[140px] max-w-[220px] relative group">
                <svg className="absolute -top-12 left-1/2 -translate-x-1/2 w-32 h-12 pointer-events-none overflow-visible" style={{ zIndex: -1 }}>
                    <path 
                        d={`M 64,50 C 64,20 ${32 + (idx % 2) * 64},20 ${32 + (idx % 2) * 64},0`} 
                        fill="none" 
                        stroke={color}
                        strokeWidth="2"
                        strokeDasharray="3,2"
                    />
                </svg>
                <div 
                  className={`border-b-2 pb-1 mb-2 font-bold text-xl text-center bg-yellow-50/50 px-3 shadow-sm transform ${idx % 2 === 0 ? 'rotate-1' : '-rotate-1'}`}
                  style={{ borderColor: color }}
                >
                  {branch.label}
                </div>
                <ul className="list-none text-center text-lg leading-snug space-y-1">
                  {branch.items.map((item, i) => (
                    <li key={i} className="relative opacity-90">
                        <span className="inline-block w-1.5 h-1.5 rounded-full mr-2 opacity-50" style={{ backgroundColor: color }}></span>
                        {item}
                    </li>
                  ))}
                </ul>
            </div>
          ))}
       </div>
       <div className="absolute inset-0 opacity-5 pointer-events-none">
           <svg width="100%" height="100%">
               <filter id="noise">
                   <feTurbulence type="fractalNoise" baseFrequency="0.8" numOctaves="3" stitchTiles="stitch" />
               </filter>
               <rect width="100%" height="100%" filter="url(#noise)" />
           </svg>
       </div>
    </div>
  );
};

const DrawingCanvas = ({ 
  initialContent, 
  penColor, 
  onSave, 
  onAnalyze 
}: { 
  initialContent: string | null, 
  penColor: string, 
  onSave: (content: string) => void,
  onAnalyze: (base64: string) => void
}) => {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const fabricCanvasRef = useRef<any>(null);
  const containerRef = useRef<HTMLDivElement>(null);
  const [isReady, setIsReady] = useState(false);

  useEffect(() => {
    const interval = setInterval(() => {
      if (window.fabric) {
        setIsReady(true);
        clearInterval(interval);
      }
    }, 100);
    return () => clearInterval(interval);
  }, []);

  useLayoutEffect(() => {
    if (!canvasRef.current || !isReady || !window.fabric) return;

    const canvas = new window.fabric.Canvas(canvasRef.current, {
      isDrawingMode: true,
      backgroundColor: 'transparent',
    });
    
    if (containerRef.current) {
      canvas.setWidth(containerRef.current.offsetWidth);
      canvas.setHeight(300);
    }

    if (initialContent) {
      const contentStr = initialContent.trim();
      if (contentStr.startsWith('<svg') || contentStr.startsWith('<?xml')) {
          window.fabric.loadSVGFromString(contentStr, (objects: any[], options: any) => {
              if (objects && objects.length > 0) {
                  const obj = window.fabric.util.groupSVGElements(objects, options);
                  const scaleX = (canvas.getWidth() * 0.8) / obj.width;
                  const scaleY = (canvas.getHeight() * 0.8) / obj.height;
                  const scale = Math.min(scaleX, scaleY, 1);
                  obj.scale(scale);
                  obj.set({
                      left: canvas.getWidth() / 2,
                      top: canvas.getHeight() / 2,
                      originX: 'center',
                      originY: 'center'
                  });
                  canvas.add(obj);
                  canvas.renderAll();
                  onSave(JSON.stringify(canvas.toJSON()));
                  canvas.isDrawingMode = false;
              }
          });
      } else {
          try {
              canvas.loadFromJSON(JSON.parse(initialContent), () => {
                  canvas.setBackgroundColor('transparent', canvas.renderAll.bind(canvas));
              });
          } catch (e) { console.error("Failed to load drawing JSON", e); }
      }
    }

    canvas.freeDrawingBrush = new window.fabric.PencilBrush(canvas);
    canvas.freeDrawingBrush.width = 3;
    canvas.freeDrawingBrush.color = penColor;

    canvas.on('path:created', () => {
      onSave(JSON.stringify(canvas.toJSON()));
    });
    canvas.on('object:modified', () => {
      onSave(JSON.stringify(canvas.toJSON()));
    });

    fabricCanvasRef.current = canvas;

    return () => {
      canvas.dispose();
    };
  }, [isReady]); 

  useEffect(() => {
    if (fabricCanvasRef.current && fabricCanvasRef.current.freeDrawingBrush) {
      fabricCanvasRef.current.freeDrawingBrush.color = penColor;
    }
  }, [penColor, isReady]);

  const handleAnalyze = () => {
    if (fabricCanvasRef.current) {
      const dataURL = fabricCanvasRef.current.toDataURL({
        format: 'png',
        quality: 1,
        multiplier: 1
      });
      const base64 = dataURL.split(',')[1];
      onAnalyze(base64);
    }
  };

  const clearCanvas = () => {
     if(fabricCanvasRef.current) {
       fabricCanvasRef.current.clear();
       fabricCanvasRef.current.setBackgroundColor('transparent', () => {
           fabricCanvasRef.current.requestRenderAll();
           onSave(JSON.stringify(fabricCanvasRef.current.toJSON()));
       });
     }
  };
  
  const toggleDrawingMode = () => {
      if (fabricCanvasRef.current) {
          fabricCanvasRef.current.isDrawingMode = !fabricCanvasRef.current.isDrawingMode;
      }
  };

  if (!isReady) return <div className="my-6 h-[300px] border-2 border-dashed border-slate-300 rounded-xl flex items-center justify-center text-slate-400">Loading Canvas...</div>;

  return (
    <div ref={containerRef} className="my-6 relative border-2 border-slate-300 rounded-xl shadow-inner overflow-hidden group" style={{ backgroundImage: 'linear-gradient(#e2e8f0 1px, transparent 1px)', backgroundSize: '100% 2rem' }}>
      <div className="absolute inset-0 opacity-10 pointer-events-none z-0 mix-blend-multiply">
           <svg width="100%" height="100%">
               <filter id="canvasNoise">
                   <feTurbulence type="fractalNoise" baseFrequency="0.6" numOctaves="3" stitchTiles="stitch" />
               </filter>
               <rect width="100%" height="100%" filter="url(#canvasNoise)" />
           </svg>
      </div>
      <div className="absolute top-2 right-2 z-20 flex gap-2 opacity-0 group-hover:opacity-100 transition-opacity">
         <button onClick={toggleDrawingMode} className="bg-slate-100 text-slate-700 text-xs px-2 py-1 rounded hover:bg-slate-200">Draw/Edit</button>
         <button onClick={handleAnalyze} className="bg-blue-600 text-white text-xs px-2 py-1 rounded flex items-center gap-1 shadow hover:bg-blue-700"><BrainCircuit size={12} /> Analyze</button>
         <button onClick={clearCanvas} className="bg-slate-200 text-slate-600 text-xs px-2 py-1 rounded hover:bg-slate-300">Clear</button>
      </div>
      <canvas ref={canvasRef} className="relative z-10" />
      <div className="absolute bottom-1 left-0 w-full text-center text-[10px] text-slate-400 uppercase tracking-widest font-sans pointer-events-none select-none bg-white/50 py-0.5 z-20">Drawing Area</div>
    </div>
  );
};

const App = () => {
  const [notebook, setNotebook] = useState<NotebookState>({
    subject: 'Subject',
    chapter: 'Chapter',
    blocks: []
  });

  const [currentStyle, setCurrentStyle] = useState({
    font: FontStyle.REGULAR,
    color: PenColor.BLUE,
    highlight: HighlighterColor.NONE,
  });
  
  const [notebookTheme, setNotebookTheme] = useState<NotebookTheme>(NotebookTheme.RULED);
  const [customFontLoaded, setCustomFontLoaded] = useState(false);
  const [isEraserMode, setIsEraserMode] = useState(false);
  const [isCameraOn, setIsCameraOn] = useState(false);
  const [isCommandOpen, setIsCommandOpen] = useState(false);
  const [isFontMenuOpen, setIsFontMenuOpen] = useState(false);
  const [isThemeMenuOpen, setIsThemeMenuOpen] = useState(false);
  const [commandInput, setCommandInput] = useState('');
  const [isConnecting, setIsConnecting] = useState(false);
  const [pendingCommand, setPendingCommand] = useState<string | null>(null);
  
  const videoRef = useRef<HTMLVideoElement>(null);
  const bottomRef = useRef<HTMLDivElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const fontInputRef = useRef<HTMLInputElement>(null);

  const handleAddBlock = (type: NoteBlockType, content: any) => {
    setNotebook(prev => ({
      ...prev,
      blocks: [
        ...prev.blocks,
        {
          id: Math.random().toString(36).substring(7),
          type,
          content,
          font: currentStyle.font,
          color: currentStyle.color,
          highlight: currentStyle.highlight,
          timestamp: Date.now()
        }
      ]
    }));
  };

  const handleUpdateBlockContent = (id: string, newContent: any) => {
      setNotebook(prev => ({
          ...prev,
          blocks: prev.blocks.map(b => b.id === id ? { ...b, content: newContent } : b)
      }));
  };

  const handleDeleteBlock = (id: string) => {
    setNotebook(prev => ({
      ...prev,
      blocks: prev.blocks.filter(b => b.id !== id)
    }));
  };

  const handleUpdateStyle = (style: { font?: FontStyle; color?: PenColor; highlight?: HighlighterColor }) => {
    setCurrentStyle(prev => ({ ...prev, ...style }));
    if (style.color || style.highlight) {
      setIsEraserMode(false);
    }
  };

  const handleSetMetadata = (subject: string, chapter: string) => {
    setNotebook(prev => ({ ...prev, subject, chapter }));
  };
  
  const handleFontUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    try {
      const buffer = await file.arrayBuffer();
      const fontFace = new FontFace('CustomHandwriting', buffer);
      await fontFace.load();
      document.fonts.add(fontFace);
      setCustomFontLoaded(true);
      handleUpdateStyle({ font: FontStyle.CUSTOM });
      setIsFontMenuOpen(false);
    } catch (err) {
      console.error("Failed to load font", err);
      alert("Failed to load font. Please ensure it is a valid TTF or OTF file.");
    }
  };

  const { connect, disconnect, isConnected, errorMessage, startVideo, stopVideo, sendImage, sendText, volume, setVolume, isMicOn, toggleMic, analyserNode } = useLiveAPI({
    onAddBlock: handleAddBlock,
    onUpdateStyle: handleUpdateStyle,
    onSetMetadata: handleSetMetadata
  });

  const handleConnect = async () => {
    if (isConnected) {
      await disconnect();
    } else {
      setIsConnecting(true);
      await connect();
      setIsConnecting(false);
    }
  };

  useEffect(() => {
    if (errorMessage || isConnected) {
        setIsConnecting(false);
    }
  }, [errorMessage, isConnected]);

  // Auto-Send Pending Commands after connection
  useEffect(() => {
      if (isConnected && pendingCommand) {
          sendText(pendingCommand);
          setPendingCommand(null);
      }
  }, [isConnected, pendingCommand, sendText]);

  const toggleCamera = () => {
    if (isCameraOn) {
        stopVideo();
        setIsCameraOn(false);
    } else {
        setIsCameraOn(true);
        setTimeout(() => {
            if (videoRef.current && isConnected) {
                startVideo(videoRef.current);
            }
        }, 50);
    }
  };

  const handleSendCommand = () => {
    if (!commandInput.trim()) return;
    
    const ytRegex = /^(https?\:\/\/)?(www\.youtube\.com|youtu\.?be)\/.+$/;
    let finalCommand = commandInput;
    if (ytRegex.test(commandInput.trim())) {
       finalCommand = `Research this video content fully using Google Search, finding transcript or summary, and create structured notes for it: ${commandInput}`;
    }

    if (isConnected) {
        sendText(finalCommand);
    } else {
        // Auto-Connect logic
        setPendingCommand(finalCommand);
        setIsConnecting(true);
        connect().then(() => setIsConnecting(false));
    }
    setCommandInput('');
  };

  const handleQuiz = () => {
    const cmd = "Please generate a Quiz with 5 MCQs, 5 Short Answer questions, and 1 Long Answer question based on the current notes. Write them down in the notebook using 'addNoteBlock'.";
    if (isConnected) sendText(cmd);
    else {
        setPendingCommand(cmd);
        connect();
    }
  };

  const handleMindMapRequest = () => {
    const cmd = "Create a structured MIND_MAP summarizing the key concepts of the current topic. Use the 'addNoteBlock' tool with type 'MIND_MAP'.";
    if (isConnected) sendText(cmd);
    else {
        setPendingCommand(cmd);
        connect();
    }
  };

  const handleAddTextBox = () => {
    const text = window.prompt("Enter text for the sticky note:");
    if (text) {
        handleAddBlock(NoteBlockType.TEXTBOX, text);
    }
  };
  
  const handleAddRichText = () => {
    handleAddBlock(NoteBlockType.RICH_TEXT, "<p>Start typing...</p>");
  };

  const handleImageUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        const base64String = reader.result as string;
        handleAddBlock(NoteBlockType.IMAGE, base64String);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleExportPDF = () => {
    const element = document.getElementById('notebook-container');
    if (!element || !window.html2pdf) return;
    const opt = {
      margin: [0.3, 0.3, 0.5, 0.3],
      filename: `SPNotes-${notebook.subject}-${notebook.chapter}.pdf`,
      image: { type: 'jpeg', quality: 0.98 },
      html2canvas: { scale: 2, useCORS: true, logging: false },
      jsPDF: { unit: 'in', format: 'letter', orientation: 'portrait' }
    };
    window.html2pdf().set(opt).from(element).save();
  };

  const handleExportImage = async () => {
      const element = document.getElementById('notebook-container');
      if (!element || !window.html2canvas) return;
      
      try {
          const canvas = await window.html2canvas(element, { scale: 2, useCORS: true, logging: false });
          const link = document.createElement('a');
          link.download = `SPNotes-${notebook.subject}-${notebook.chapter}.png`;
          link.href = canvas.toDataURL('image/png');
          link.click();
      } catch (err) {
          console.error("Image export failed", err);
      }
  };

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [notebook.blocks]);

  useEffect(() => {
    if (!isConnected && isCameraOn) {
        setIsCameraOn(false);
        stopVideo();
    }
  }, [isConnected, isCameraOn, stopVideo]);

  const getNotebookStyle = (theme: NotebookTheme) => {
      const base = {
          backgroundSize: '100% 2rem',
          backgroundColor: '#fdfbf7', // Default off-white
          backgroundImage: 'linear-gradient(#e2e8f0 1px, transparent 1px)',
          color: '#1e293b',
      };

      switch (theme) {
          case NotebookTheme.RULED:
              return { 
                  ...base,
                  position: 'relative' as const,
              };
          case NotebookTheme.GRID:
              return {
                  ...base,
                  backgroundImage: 'linear-gradient(#e2e8f0 1px, transparent 1px), linear-gradient(90deg, #e2e8f0 1px, transparent 1px)',
                  backgroundSize: '2rem 2rem'
              };
          case NotebookTheme.DOTTED:
              return {
                  ...base,
                  backgroundImage: 'radial-gradient(#cbd5e1 1px, transparent 1px)',
                  backgroundSize: '1.5rem 1.5rem'
              };
          case NotebookTheme.BLANK:
              return { ...base, backgroundImage: 'none' };
          case NotebookTheme.EXAM:
              return {
                  ...base,
                  backgroundColor: '#ffffff',
                  border: '1px solid #cbd5e1',
                  boxShadow: '0 0 20px rgba(0,0,0,0.05) inset'
              };
          case NotebookTheme.DARK:
              return {
                  ...base,
                  backgroundColor: '#1e293b',
                  backgroundImage: 'none',
                  color: '#f8fafc' // Light text
              };
          default:
              return base;
      }
  };

  const notebookStyle = getNotebookStyle(notebookTheme);

  const renderBlock = (block: NoteBlock) => {
    const isDarkTheme = notebookTheme === NotebookTheme.DARK;
    const style = {
      fontFamily: FONT_FAMILY_MAP[block.font],
      color: isDarkTheme && block.color === PenColor.BLACK ? '#f8fafc' : PEN_COLOR_MAP[block.color],
      backgroundColor: HIGHLIGHTER_COLOR_MAP[block.highlight],
    };

    const updateContent = (val: string) => handleUpdateBlockContent(block.id, val);

    switch (block.type) {
      case NoteBlockType.HEADING:
        return (
          <Editable 
            tagName="h1"
            content={block.content as string}
            onSave={updateContent}
            disabled={isEraserMode}
            style={style} 
            className="text-4xl font-bold mb-4 mt-8 border-b-2 border-slate-300/50 pb-2 w-full"
          />
        );
      case NoteBlockType.SUBHEADING:
        return (
          <Editable
            tagName="h2"
            content={block.content as string}
            onSave={updateContent}
            disabled={isEraserMode}
            style={style} 
            className="text-2xl font-bold mb-3 mt-5 underline decoration-wavy decoration-slate-300/60"
          />
        );
      case NoteBlockType.PARAGRAPH:
        return (
          <Editable
            tagName="p"
            content={block.content as string}
            onSave={updateContent}
            disabled={isEraserMode}
            style={style} 
            className="text-xl leading-8 mb-4 text-justify"
          />
        );
      case NoteBlockType.BULLET:
        return (
          <div style={style} className="flex items-start mb-2 text-xl ml-4">
            <span className="mr-3 mt-2 h-1.5 w-1.5 rounded-full bg-current flex-shrink-0 opacity-80" />
            <Editable
                tagName="span"
                content={block.content as string}
                onSave={updateContent}
                disabled={isEraserMode}
                className="leading-relaxed flex-1"
            />
          </div>
        );
      case NoteBlockType.DEFINITION:
        return (
          <div style={{ ...style, backgroundColor: isDarkTheme ? 'rgba(59, 130, 246, 0.2)' : 'rgba(240, 249, 255, 0.6)' }} className="border-l-[3px] border-blue-400 pl-5 py-3 my-5 rounded-r-lg shadow-sm">
            <span className="font-bold text-xs uppercase tracking-widest opacity-50 block mb-2 font-sans">Definition</span>
            <Editable
                tagName="p"
                content={block.content as string}
                onSave={updateContent}
                disabled={isEraserMode}
                className="text-xl font-medium"
            />
          </div>
        );
      case NoteBlockType.TEXTBOX:
        return (
            <div 
              style={{ fontFamily: FONT_FAMILY_MAP[block.font], color: '#1e293b' }} 
              className="bg-yellow-100 p-4 shadow-lg transform rotate-1 max-w-sm border-t-8 border-yellow-200/50 mx-4 my-6 relative handwritten-shadow"
            >
               <div className="absolute -top-3 left-1/2 -translate-x-1/2 w-20 h-4 bg-yellow-200/60 opacity-70 rotate-1"></div>
               <Editable
                    tagName="p"
                    content={block.content as string}
                    onSave={updateContent}
                    disabled={isEraserMode}
                    className="text-lg leading-relaxed whitespace-pre-wrap"
               />
            </div>
        );
      case NoteBlockType.RICH_TEXT:
        return (
            <RichTextEditor 
               id={block.id} 
               initialContent={block.content as string}
               onUpdate={updateContent}
            />
        );
      case NoteBlockType.TABLE:
        const tableData = safeParse(block.content);
        if (!tableData || !tableData.headers) return null;
        const handleCellUpdate = (rowIndex: number, colIndex: number, newVal: string) => {
            const newData = { ...tableData };
            newData.rows = newData.rows.map((row: string[], r: number) => 
                r === rowIndex ? row.map((cell, c) => c === colIndex ? newVal : cell) : row
            );
            updateContent(JSON.stringify(newData));
        };
        return (
          <div className={`my-8 overflow-hidden border-2 border-slate-700 rounded-sm transform -rotate-1 shadow-[4px_4px_0px_rgba(0,0,0,0.1)] ${isDarkTheme ? 'bg-slate-800' : 'bg-white/80'}`}>
            <table className="w-full text-lg" style={{ fontFamily: FONT_FAMILY_MAP[block.font], color: isDarkTheme ? '#e2e8f0' : PEN_COLOR_MAP[block.color] }}>
              <thead>
                <tr className={`border-b-2 border-slate-700 ${isDarkTheme ? 'bg-slate-900' : 'bg-slate-100'}`}>
                  {tableData.headers.map((h: string, i: number) => (
                    <th key={i} className="p-3 border-r-2 border-slate-700 last:border-r-0 text-left font-bold">{h}</th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {tableData.rows.map((row: string[], i: number) => (
                  <tr key={i} className={`border-b border-slate-700 last:border-b-0 ${isDarkTheme ? 'hover:bg-slate-700' : 'hover:bg-yellow-50/30'}`}>
                    {row.map((cell, j) => (
                      <td key={j} className="p-3 border-r border-slate-700 last:border-r-0">
                          <Editable 
                             content={cell} 
                             onSave={(val) => handleCellUpdate(i, j, val)} 
                             disabled={isEraserMode}
                          />
                      </td>
                    ))}
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        );
      case NoteBlockType.FLOWCHART:
         return (
            <div className={`my-6 p-6 border-2 border-dashed border-slate-400 rounded-xl flex flex-col items-center gap-3 ${isDarkTheme ? 'bg-white/5 border-slate-600' : 'bg-white/40'}`}>
              <span className="text-xs text-slate-400 font-sans uppercase tracking-widest">Process Flow</span>
              <Editable
                 tagName="div"
                 content={block.content as string}
                 onSave={updateContent}
                 disabled={isEraserMode}
                 style={style}
                 className="text-xl text-center whitespace-pre-wrap font-semibold"
              />
            </div>
         );
      case NoteBlockType.FLASHCARD:
        const flashcard = safeParse(block.content);
        if (!flashcard || !flashcard.term) return null;
        const updateFlashcard = (field: 'term' | 'definition', val: string) => {
            const newCard = { ...flashcard, [field]: val };
            updateContent(JSON.stringify(newCard));
        };
        return (
          <div className="my-8 p-6 bg-gradient-to-br from-yellow-50 to-yellow-100 shadow-md rounded-sm rotate-1 border border-yellow-200 max-w-md mx-auto relative">
            <div className="absolute -top-3 left-1/2 -translate-x-1/2 w-16 h-4 bg-yellow-200/50 rotate-2"></div>
            <div style={{...style, color: '#1e293b'}} className="text-center">
              <div className="border-b-2 border-yellow-200/50 pb-2 mb-3">
                  <Editable
                    tagName="h3"
                    content={flashcard.term}
                    onSave={(val) => updateFlashcard('term', val)}
                    disabled={isEraserMode}
                    className="text-2xl font-bold opacity-90"
                  />
              </div>
              <Editable
                tagName="p"
                content={flashcard.definition}
                onSave={(val) => updateFlashcard('definition', val)}
                disabled={isEraserMode}
                className="text-xl opacity-80"
              />
            </div>
          </div>
        );
      case NoteBlockType.MIND_MAP:
        const mindMap = safeParse(block.content);
        if (!mindMap || !mindMap.center) return null;
        return (
          <HandwrittenMindMap 
            data={mindMap} 
            fontStyle={FONT_FAMILY_MAP[block.font]} 
            color={isDarkTheme ? '#cbd5e1' : PEN_COLOR_MAP[block.color]}
          />
        );
      case NoteBlockType.DRAWING:
        return (
          <DrawingCanvas 
            initialContent={block.content as string}
            penColor={isDarkTheme ? '#cbd5e1' : PEN_COLOR_MAP[block.color]}
            onSave={updateContent}
            onAnalyze={sendImage}
          />
        );
      case NoteBlockType.IMAGE:
        const imgSrc = block.content as string;
        return (
            <div className="my-8 relative group inline-block transform -rotate-1 hover:rotate-0 transition-transform duration-300">
                <div className="absolute -top-4 left-1/2 -translate-x-1/2 w-32 h-8 bg-yellow-200/40 shadow-sm rotate-1 z-10 backdrop-blur-sm"></div>
                <div className="bg-white p-3 pb-10 shadow-lg border border-slate-200 rounded-sm">
                   <img src={imgSrc} alt="Imported note" className="max-w-full md:max-w-lg rounded-sm filter contrast-105" />
                </div>
                <div className="absolute bottom-3 right-3 opacity-0 group-hover:opacity-100 transition-opacity">
                   <button 
                     onClick={() => {
                       const base64 = imgSrc.includes(',') ? imgSrc.split(',')[1] : imgSrc;
                       sendImage(base64);
                     }} 
                     className="bg-blue-600 text-white text-xs px-3 py-1.5 rounded-full shadow-lg flex items-center gap-1 hover:bg-blue-700 transform hover:scale-105 transition-all"
                   >
                      <BrainCircuit size={14} /> Analyze
                   </button>
                </div>
            </div>
        );
      default: return null;
    }
  };

  return (
    <div className={`h-screen flex flex-col bg-slate-100 ${isEraserMode ? 'cursor-crosshair' : ''}`}>
      <input type="file" ref={fileInputRef} accept="image/*" onChange={handleImageUpload} className="hidden" />
      <input type="file" ref={fontInputRef} accept=".ttf,.otf,.woff" onChange={handleFontUpload} className="hidden" />

      <header className="h-16 bg-slate-800 text-white flex items-center justify-between px-4 shadow-lg z-10 flex-shrink-0">
        <div className="flex items-center gap-3 select-none">
          <div className="relative w-10 h-10 bg-white rounded-lg shadow-sm overflow-hidden flex items-center justify-center flex-shrink-0">
             <BookOpen className="text-slate-900 w-6 h-6 absolute" />
             <img src="logo.png" alt="HandNote AI" className="relative z-10 w-full h-full object-cover" onError={(e) => e.currentTarget.style.display = 'none'} />
          </div>
          <div className="hidden md:flex flex-col leading-none justify-center">
            <span className="text-xl font-bold tracking-wide text-white font-sans">HandNote AI</span>
          </div>
        </div>
        <div className="flex-1 flex justify-center px-2 min-w-0">
           <div className="flex flex-col items-center truncate">
              <span className="text-[9px] md:text-[10px] text-slate-400 uppercase tracking-wider">Current Topic</span>
              <div className="flex items-center gap-2">
                  <Editable tagName="span" content={notebook.subject} onSave={(val) => handleSetMetadata(val, notebook.chapter)} disabled={false} className="font-hand text-base md:text-lg font-bold text-blue-200 truncate max-w-[100px]" />
                  <span className="text-slate-500">&bull;</span>
                  <Editable tagName="span" content={notebook.chapter} onSave={(val) => handleSetMetadata(notebook.subject, val)} disabled={false} className="font-hand text-base md:text-lg font-bold text-blue-200 truncate max-w-[150px]" />
              </div>
           </div>
        </div>

        <div className="flex items-center gap-2 md:gap-4">
            {isConnected && (
               <DigitalRecorder 
                 isConnected={isConnected} 
                 isMicOn={isMicOn}
                 volume={volume} 
                 onToggleMic={toggleMic}
                 onVolumeChange={setVolume} 
                 analyser={analyserNode} 
               />
            )}
            <div className="hidden md:flex items-center gap-2">
                {/* Theme Selector */}
                <div className="relative">
                     <button onClick={() => setIsThemeMenuOpen(!isThemeMenuOpen)} className="p-2 text-slate-300 hover:text-white hover:bg-slate-700 rounded-full" title="Notebook Theme">
                        <Palette size={20} />
                     </button>
                     {isThemeMenuOpen && (
                        <>
                            <div className="fixed inset-0 z-40" onClick={() => setIsThemeMenuOpen(false)} />
                            <div className="absolute top-full right-0 mt-2 w-40 bg-white rounded-xl shadow-xl border border-slate-200 overflow-hidden z-50">
                                {Object.values(NotebookTheme).map((theme) => (
                                    <button key={theme} onClick={() => { setNotebookTheme(theme); setIsThemeMenuOpen(false); }} className={`w-full text-left px-4 py-2 hover:bg-slate-50 text-sm text-slate-700 ${notebookTheme === theme ? 'bg-blue-50 font-bold' : ''}`}>
                                        {theme}
                                    </button>
                                ))}
                            </div>
                        </>
                     )}
                </div>

                <div className="relative">
                    <button onClick={() => setIsFontMenuOpen(!isFontMenuOpen)} className="flex items-center gap-1 bg-slate-700/50 hover:bg-slate-600 text-white px-2 py-1.5 rounded-lg transition-all border border-transparent hover:border-slate-500">
                        <span className="hidden xl:inline text-sm font-medium opacity-90">Style</span>
                        <ChevronDown size={16} className={`transition-transform ${isFontMenuOpen ? 'rotate-180' : ''}`} />
                    </button>
                    {isFontMenuOpen && (
                        <>
                            <div className="fixed inset-0 z-40" onClick={() => setIsFontMenuOpen(false)} />
                            <div className="absolute top-full right-0 mt-2 w-56 bg-white rounded-xl shadow-xl border border-slate-200 overflow-hidden z-50">
                                <div className="px-4 py-2 bg-slate-50 border-b border-slate-100 text-xs font-bold text-slate-400 uppercase tracking-wider">Select Handwriting</div>
                                <div className="max-h-[300px] overflow-y-auto">
                                    {Object.values(FontStyle).map((font) => (
                                        <button key={font} onClick={() => { handleUpdateStyle({ font }); setIsFontMenuOpen(false); }} className={`w-full text-left px-4 py-3 hover:bg-slate-50 transition-colors flex items-center justify-between group ${currentStyle.font === font ? 'bg-blue-50/50' : ''}`}>
                                            <span style={{ fontFamily: FONT_FAMILY_MAP[font] }} className="text-lg text-slate-700">{font === FontStyle.CUSTOM && !customFontLoaded ? 'Custom Font (Not Loaded)' : font}</span>
                                            {currentStyle.font === font && <div className="w-2 h-2 rounded-full bg-blue-500" />}
                                        </button>
                                    ))}
                                </div>
                                <div className="border-t border-slate-100 p-2 bg-slate-50">
                                    <button onClick={() => fontInputRef.current?.click()} className="w-full flex items-center justify-center gap-2 text-sm text-slate-600 hover:text-blue-600 py-2 rounded hover:bg-blue-50 transition-colors border border-dashed border-slate-300 hover:border-blue-400">
                                        <Upload size={14} /> Upload Your Font
                                    </button>
                                </div>
                            </div>
                        </>
                    )}
                </div>
                <div className="flex items-center gap-1 bg-slate-700/50 p-1 rounded-full">
                  {Object.values(PenColor).map((color) => (
                    <button key={color} onClick={() => handleUpdateStyle({ color })} className={`w-4 h-4 rounded-full border-[1.5px] transition-all hover:scale-110 ${currentStyle.color === color && !isEraserMode ? 'border-white scale-110 shadow-[0_0_8px_rgba(255,255,255,0.4)]' : 'border-transparent opacity-70 hover:opacity-100'}`} style={{ backgroundColor: PEN_COLOR_MAP[color] }} title={`Pen: ${color}`} />
                  ))}
                </div>
                <div className="flex items-center gap-1 bg-slate-700/50 p-1 rounded-full border-l border-slate-600 pl-2 ml-1">
                    <button onClick={() => handleUpdateStyle({ highlight: HighlighterColor.NONE })} className={`w-4 h-4 rounded-full border border-slate-500 flex items-center justify-center transition-all ${currentStyle.highlight === HighlighterColor.NONE ? 'bg-slate-500 scale-110' : 'bg-transparent hover:bg-slate-600'}`} title="No Highlight"><X size={10} className="text-white" /></button>
                    <button onClick={() => handleUpdateStyle({ highlight: HighlighterColor.YELLOW })} className={`w-4 h-4 rounded-full border-[1.5px] transition-all hover:scale-110 ${currentStyle.highlight === HighlighterColor.YELLOW ? 'border-white scale-110' : 'border-transparent opacity-70'}`} style={{ backgroundColor: '#fde047' }} title="Yellow Highlight" />
                    <button onClick={() => handleUpdateStyle({ highlight: HighlighterColor.BLUE })} className={`w-4 h-4 rounded-full border-[1.5px] transition-all hover:scale-110 ${currentStyle.highlight === HighlighterColor.BLUE ? 'border-white scale-110' : 'border-transparent opacity-70'}`} style={{ backgroundColor: '#93c5fd' }} title="Blue Highlight" />
                </div>
            </div>
           <div className="flex items-center gap-2">
             <button onClick={() => setIsCommandOpen(true)} className="flex md:hidden lg:flex items-center gap-1 px-2 py-1.5 bg-red-600 text-white rounded hover:bg-red-700 transition-colors" title="Add YouTube Video"><Youtube size={18} /></button>
             <button onClick={() => fileInputRef.current?.click()} className="hidden md:flex items-center gap-1 px-2 py-1.5 bg-slate-700 text-slate-300 rounded hover:bg-slate-600 transition-colors" title="Import Image"><ImageIcon size={18} /></button>
             <button onClick={handleExportPDF} className="hidden md:flex items-center gap-1 px-2 py-1.5 bg-slate-700 text-slate-300 rounded hover:bg-slate-600 transition-colors" title="Export PDF"><FileDown size={18} /></button>
             <button onClick={handleExportImage} className="hidden md:flex items-center gap-1 px-2 py-1.5 bg-slate-700 text-slate-300 rounded hover:bg-slate-600 transition-colors" title="Export Image"><ImageIcon size={18} /></button>
             <button onClick={handleMindMapRequest} disabled={!isConnected} className="hidden lg:flex items-center gap-1 px-2 py-1.5 bg-teal-600 text-white rounded hover:bg-teal-700 disabled:opacity-50 disabled:cursor-not-allowed" title="Create Mind Map"><Network size={18} /></button>
             <button onClick={handleQuiz} disabled={!isConnected} className="hidden lg:flex items-center gap-1 px-3 py-1.5 bg-violet-600 text-white rounded-md text-sm hover:bg-violet-700 disabled:opacity-50 disabled:cursor-not-allowed" title="Generate Quiz"><HelpCircle size={16} /> Quiz</button>
             <button onClick={() => setIsCommandOpen(!isCommandOpen)} className={`p-2 rounded-full transition-colors ${isCommandOpen ? 'bg-blue-600 text-white' : 'bg-slate-700 text-slate-300 hover:bg-slate-600'}`} title="Type Text / Link"><MessageSquare size={20} /></button>
             <button onClick={handleAddRichText} className="p-2 rounded-full bg-slate-700 text-slate-300 hover:bg-slate-600 transition-colors hidden sm:block" title="Add Rich Text Editor"><FileText size={20} /></button>
             <button onClick={handleAddTextBox} className="p-2 rounded-full bg-slate-700 text-slate-300 hover:bg-slate-600 transition-colors" title="Add Sticky Note"><StickyNote size={20} /></button>
             <button onClick={() => handleAddBlock(NoteBlockType.DRAWING, null)} className="p-2 rounded-full bg-slate-700 text-slate-300 hover:bg-slate-600 transition-colors hidden sm:block" title="Add Drawing"><Pencil size={20} /></button>
             <button onClick={() => setIsEraserMode(!isEraserMode)} className={`p-2 rounded-full transition-all duration-200 ${isEraserMode ? 'bg-pink-100 text-pink-600 shadow-[inset_0_2px_4px_rgba(0,0,0,0.1)] ring-2 ring-pink-500/50' : 'bg-slate-700 text-slate-300 hover:bg-slate-600'}`} title="Eraser Tool"><Eraser size={20} /></button>
             <button onClick={toggleCamera} disabled={!isConnected} className={`p-2 rounded-full transition-colors ${isCameraOn ? 'bg-green-600 text-white' : 'bg-slate-700 text-slate-300 hover:bg-slate-600'} ${!isConnected ? 'opacity-50 cursor-not-allowed' : ''}`} title="Toggle Camera">{isCameraOn ? <Camera size={20} /> : <CameraOff size={20} />}</button>
           </div>
           
           {/* Dedicated Mic Toggle Button */}
           {isConnected && (
              <button 
                onClick={toggleMic} 
                className={`flex items-center gap-2 px-4 py-2 rounded-full font-bold transition-all whitespace-nowrap mr-2 ${isMicOn ? 'bg-slate-700 hover:bg-slate-600 text-white' : 'bg-red-600 hover:bg-red-700 text-white'}`}
              >
                {isMicOn ? <Mic size={20} /> : <MicOff size={20} />}
                <span className="hidden sm:inline">{isMicOn ? "Mic Off" : "Mic On"}</span>
              </button>
           )}

           <button onClick={handleConnect} disabled={isConnecting} className={`flex items-center gap-2 px-4 py-2 rounded-full font-bold transition-all whitespace-nowrap ${isConnected ? 'bg-red-500 hover:bg-red-600 text-white shadow-[0_0_15px_rgba(239,68,68,0.5)]' : 'bg-blue-600 hover:bg-blue-700 text-white'} ${isConnecting ? 'opacity-80 cursor-wait' : ''}`}>
             {isConnecting ? (<Loader2 size={20} className="animate-spin" />) : isConnected ? (<Power size={20} />) : (<Power size={20} />)}
             <span className="hidden sm:inline">{isConnecting ? 'Connecting...' : isConnected ? 'Disconnect' : 'Connect'}</span>
           </button>
        </div>
      </header>

      {isCommandOpen && (
        <div className="bg-slate-700 p-2 px-4 flex gap-2 items-center animate-in slide-in-from-top-2 z-10 shadow-lg">
           <input 
             type="text" 
             value={commandInput}
             onChange={(e) => setCommandInput(e.target.value)}
             onKeyDown={(e) => e.key === 'Enter' && handleSendCommand()}
             placeholder={isConnected ? (isMicOn ? "Type to override speech..." : "Type your notes here...") : "Type here to Auto-Connect..."} 
             className="flex-1 bg-slate-600 text-white placeholder-slate-400 px-3 py-1.5 rounded focus:outline-none focus:ring-1 focus:ring-blue-400"
           />
           <button onClick={handleSendCommand} disabled={!commandInput.trim()} className="bg-blue-500 hover:bg-blue-600 disabled:bg-slate-600 disabled:text-slate-400 text-white px-3 py-1.5 rounded flex items-center gap-1"><Send size={16} /> <span className="hidden sm:inline">Send</span></button>
        </div>
      )}

      {errorMessage && (
        <div className="bg-red-100 border-l-4 border-red-500 text-red-700 p-4 mb-2 text-center" role="alert">
          <p className="font-bold">Connection Error</p>
          <p className="text-sm">{errorMessage}</p>
          <p className="text-xs mt-1 opacity-75">Please check the console for more details.</p>
        </div>
      )}

      {isCameraOn && (
        <div className="fixed bottom-24 right-8 z-20 bg-white p-2 shadow-xl transform rotate-2 rounded-sm border border-slate-200 transition-all animate-in fade-in slide-in-from-bottom-4 hidden md:block">
            <div className="relative bg-black w-48 h-36 md:w-64 md:h-48 overflow-hidden">
                <video ref={videoRef} autoPlay playsInline muted className="w-full h-full object-cover" />
                <div className="absolute top-2 right-2 px-2 py-0.5 bg-red-600 text-white text-[10px] font-bold uppercase tracking-wider rounded flex items-center gap-1"><span className="w-2 h-2 bg-white rounded-full animate-pulse"></span> LIVE</div>
            </div>
        </div>
      )}

      <main className="flex-1 overflow-y-auto relative pb-20" style={{ backgroundColor: notebookStyle.backgroundColor }}>
        <div id="notebook-container" className="max-w-4xl mx-auto min-h-full px-6 md:px-16 py-12 relative" style={notebookStyle}>
             {notebookTheme === NotebookTheme.RULED && <div className="absolute top-0 bottom-0 left-12 w-0.5 bg-red-500/30 pointer-events-none" />}
             
            {notebook.blocks.length === 0 && (
              <div className="absolute inset-0 flex flex-col items-center justify-center text-slate-400 pointer-events-none">
                <PenTool size={64} className="mb-4 opacity-20" />
                <p className="text-2xl font-hand opacity-40">Press Connect to begin...</p>
              </div>
            )}

            <div className="space-y-2">
              {notebook.blocks.map((block) => (
                <div key={block.id} onClick={() => isEraserMode && handleDeleteBlock(block.id)} className={`relative group transition-opacity ${isEraserMode ? 'cursor-pointer hover:opacity-25 hover:bg-red-100/30 rounded' : ''}`} title={isEraserMode ? "Click to erase" : ""}>
                  {isEraserMode && <div className="absolute -left-10 top-1/2 -translate-x-1/2 text-red-400 opacity-0 group-hover:opacity-100"><X size={32} /></div>}
                  {renderBlock(block)}
                </div>
              ))}
              <div ref={bottomRef} />
            </div>
        </div>
      </main>
    </div>
  );
};

export default App;